import React from 'react';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Computer World</h3>
            <p className="text-blue-200 mb-4">Expert Repairs for Desktops, Laptops, and Printers</p>
            <div className="flex items-center space-x-2 mb-2">
              <Mail size={16} className="text-blue-300" />
              <a href="mailto:dasamit00129@gmail.com" className="text-blue-200 hover:text-white transition">
                dasamit00129@gmail.com
              </a>
            </div>
            <div className="flex items-center space-x-2">
              <Phone size={16} className="text-blue-300" />
              <a href="tel:8926179060" className="text-blue-200 hover:text-white transition">
                8926179060
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Our Services</h3>
            <ul className="space-y-2 text-blue-200">
              <li className="hover:text-white transition cursor-pointer">Desktop Repair</li>
              <li className="hover:text-white transition cursor-pointer">Laptop Repair</li>
              <li className="hover:text-white transition cursor-pointer">Printer Repair</li>
              <li className="hover:text-white transition cursor-pointer">Hardware Upgrades</li>
              <li className="hover:text-white transition cursor-pointer">Software Installation</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Business Hours</h3>
            <div className="space-y-2 text-blue-200">
              <div className="flex items-center space-x-2">
                <Clock size={16} className="text-blue-300" />
                <span>Monday - Friday: 9:00 AM - 6:00 PM</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock size={16} className="text-blue-300" />
                <span>Saturday: 10:00 AM - 4:00 PM</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock size={16} className="text-blue-300" />
                <span>Sunday: Closed</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-blue-800 text-center text-blue-300">
          <p>&copy; {new Date().getFullYear()} Computer World. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;