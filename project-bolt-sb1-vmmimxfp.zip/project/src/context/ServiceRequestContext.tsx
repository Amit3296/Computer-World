import React, { createContext, useContext, useState, useEffect } from 'react';

// Define types
interface ServiceRequest {
  id: string;
  customerName: string;
  contactNumber: string;
  deviceType: string;
  make: string;
  model: string;
  serialNumber?: string;
  issue: string;
  serviceCharge: string;
  status: 'Pending' | 'In Progress' | 'Completed' | 'Cancelled';
  createdAt: string;
  estimatedCompletion: string;
}

interface ServiceRequestContextType {
  serviceRequests: ServiceRequest[];
  addServiceRequest: (request: ServiceRequest) => void;
  getServiceRequest: (id: string) => ServiceRequest | null;
  updateServiceRequest: (id: string, updates: Partial<ServiceRequest>) => void;
  removeServiceRequest: (id: string) => void;
}

// Create context
const ServiceRequestContext = createContext<ServiceRequestContextType | undefined>(undefined);

// Sample data for demonstration purposes
const sampleServiceRequests: ServiceRequest[] = [
  {
    id: '123456',
    customerName: 'John Doe',
    contactNumber: '9876543210',
    deviceType: 'Desktop',
    make: 'Dell',
    model: 'Inspiron 3000',
    serialNumber: 'DEL123456',
    issue: 'No Power',
    serviceCharge: '₹600',
    status: 'Pending',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    estimatedCompletion: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '234567',
    customerName: 'Jane Smith',
    contactNumber: '8765432109',
    deviceType: 'Laptop',
    make: 'HP',
    model: 'Pavilion 15',
    serialNumber: 'HP789012',
    issue: 'Screen Damage',
    serviceCharge: '₹1500',
    status: 'In Progress',
    createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    estimatedCompletion: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '345678',
    customerName: 'Mike Johnson',
    contactNumber: '7654321098',
    deviceType: 'Printer',
    make: 'Epson',
    model: 'L3110',
    serialNumber: 'EP345678',
    issue: 'Paper Jam issue',
    serviceCharge: '₹500',
    status: 'Completed',
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    estimatedCompletion: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString()
  }
];

// Create provider
export const ServiceRequestProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  
  // Load service requests from localStorage on initial load
  useEffect(() => {
    const storedRequests = localStorage.getItem('serviceRequests');
    if (storedRequests) {
      setServiceRequests(JSON.parse(storedRequests));
    } else {
      // Use sample data if no stored data exists
      setServiceRequests(sampleServiceRequests);
    }
  }, []);
  
  // Save service requests to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('serviceRequests', JSON.stringify(serviceRequests));
  }, [serviceRequests]);
  
  // Add a new service request
  const addServiceRequest = (request: ServiceRequest) => {
    setServiceRequests(prev => [...prev, request]);
  };
  
  // Get a service request by ID
  const getServiceRequest = (id: string): ServiceRequest | null => {
    return serviceRequests.find(request => request.id === id) || null;
  };
  
  // Update a service request
  const updateServiceRequest = (id: string, updates: Partial<ServiceRequest>) => {
    setServiceRequests(prev =>
      prev.map(request =>
        request.id === id ? { ...request, ...updates } : request
      )
    );
  };
  
  // Remove a service request
  const removeServiceRequest = (id: string) => {
    setServiceRequests(prev =>
      prev.filter(request => request.id !== id)
    );
  };
  
  return (
    <ServiceRequestContext.Provider value={{
      serviceRequests,
      addServiceRequest,
      getServiceRequest,
      updateServiceRequest,
      removeServiceRequest
    }}>
      {children}
    </ServiceRequestContext.Provider>
  );
};

// Create hook for using the context
export const useServiceRequest = (): ServiceRequestContextType => {
  const context = useContext(ServiceRequestContext);
  if (context === undefined) {
    throw new Error('useServiceRequest must be used within a ServiceRequestProvider');
  }
  return context;
};