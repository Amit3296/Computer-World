import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useServiceRequest } from '../context/ServiceRequestContext';
import { CheckCircle, AlertCircle, ClockIcon, Printer, Monitor, Laptop, FilePlus } from 'lucide-react';

const TrackingPage = () => {
  const location = useLocation();
  const { getServiceRequest } = useServiceRequest();
  const [serviceId, setServiceId] = useState('');
  const [serviceRequest, setServiceRequest] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Extract service ID from URL query parameters
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const id = params.get('id');
    if (id) {
      setServiceId(id);
      handleTrack(id);
    }
  }, [location.search]);
  
  const handleTrack = (id) => {
    setLoading(true);
    setError('');
    
    setTimeout(() => {
      const request = getServiceRequest(id);
      if (request) {
        setServiceRequest(request);
        setError('');
      } else {
        setServiceRequest(null);
        setError('Service request not found. Please check the ID and try again.');
      }
      setLoading(false);
    }, 1000);
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!serviceId.trim()) {
      setError('Please enter a service ID');
      return;
    }
    handleTrack(serviceId);
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800';
      case 'Completed':
        return 'bg-green-100 text-green-800';
      case 'Cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getDeviceIcon = (type) => {
    switch (type) {
      case 'Desktop':
        return <Monitor size={24} />;
      case 'Laptop':
        return <Laptop size={24} />;
      case 'Printer':
        return <Printer size={24} />;
      default:
        return <Monitor size={24} />;
    }
  };
  
  return (
    <div className="py-10 bg-gray-50 min-h-[calc(100vh-64px-275px)]">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-blue-800 px-6 py-4">
            <h1 className="text-2xl font-bold text-white">Track Your Service Request</h1>
          </div>
          
          <div className="p-6">
            <form onSubmit={handleSubmit} className="mb-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-grow">
                  <label htmlFor="serviceId" className="block text-sm font-medium text-gray-700 mb-1">
                    Service Request ID
                  </label>
                  <input
                    type="text"
                    id="serviceId"
                    value={serviceId}
                    onChange={(e) => {
                      setServiceId(e.target.value);
                      setError('');
                    }}
                    placeholder="Enter your 6-digit service ID"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div className="self-end">
                  <button
                    type="submit"
                    disabled={loading}
                    className={`w-full md:w-auto px-6 py-2 bg-blue-800 text-white rounded-lg font-semibold ${
                      loading ? 'opacity-70 cursor-not-allowed' : 'hover:bg-blue-700'
                    } transition duration-200`}
                  >
                    {loading ? 'Tracking...' : 'Track'}
                  </button>
                </div>
              </div>
            </form>
            
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <div className="flex">
                  <AlertCircle size={20} className="text-red-500 mr-2" />
                  <p className="text-red-600">{error}</p>
                </div>
              </div>
            )}
            
            {loading && (
              <div className="flex justify-center items-center py-12">
                <svg className="animate-spin h-8 w-8 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
            )}
            
            {serviceRequest && !loading && (
              <div className="space-y-6">
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                      <h2 className="text-lg font-semibold text-gray-900">Service Request #{serviceRequest.id}</h2>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(serviceRequest.status)}`}>
                        {serviceRequest.status}
                      </span>
                    </div>
                  </div>
                  
                  <div className="px-4 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Customer Information</h3>
                        <p className="mt-1 text-sm text-gray-900">{serviceRequest.customerName}</p>
                        <p className="mt-1 text-sm text-gray-900">{serviceRequest.contactNumber}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Service Details</h3>
                        <div className="mt-1 flex items-center">
                          {getDeviceIcon(serviceRequest.deviceType)}
                          <span className="ml-2 text-sm text-gray-900">
                            {serviceRequest.deviceType} - {serviceRequest.make} {serviceRequest.model}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-gray-900">Issue: {serviceRequest.issue}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Service Charge</h3>
                        <p className="mt-1 text-sm text-gray-900">{serviceRequest.serviceCharge}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Estimated Completion</h3>
                        <p className="mt-1 text-sm text-gray-900">
                          {new Date(serviceRequest.estimatedCompletion).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                    <h2 className="text-lg font-semibold text-gray-900">Service Status Timeline</h2>
                  </div>
                  
                  <div className="px-4 py-4">
                    <ol className="relative border-l border-gray-200 ml-3">
                      <li className="mb-6 ml-6">
                        <span className="absolute flex items-center justify-center w-6 h-6 bg-blue-100 rounded-full -left-3 ring-8 ring-white">
                          <CheckCircle size={16} className="text-blue-800" />
                        </span>
                        <h3 className="flex items-center text-lg font-semibold text-gray-900">Service Request Received</h3>
                        <time className="block mb-2 text-sm font-normal leading-none text-gray-500">
                          {new Date(serviceRequest.createdAt).toLocaleString()}
                        </time>
                        <p className="text-sm font-normal text-gray-600">
                          Your service request has been received and is being reviewed by our technicians.
                        </p>
                      </li>
                      
                      {serviceRequest.status !== 'Pending' && (
                        <li className="mb-6 ml-6">
                          <span className="absolute flex items-center justify-center w-6 h-6 bg-blue-100 rounded-full -left-3 ring-8 ring-white">
                            <ClockIcon size={16} className="text-blue-800" />
                          </span>
                          <h3 className="flex items-center text-lg font-semibold text-gray-900">Diagnostic In Progress</h3>
                          <time className="block mb-2 text-sm font-normal leading-none text-gray-500">
                            {new Date(new Date(serviceRequest.createdAt).getTime() + 24 * 60 * 60 * 1000).toLocaleString()}
                          </time>
                          <p className="text-sm font-normal text-gray-600">
                            Our technicians are diagnosing your device to identify the issue.
                          </p>
                        </li>
                      )}
                      
                      {serviceRequest.status === 'Completed' && (
                        <li className="ml-6">
                          <span className="absolute flex items-center justify-center w-6 h-6 bg-green-100 rounded-full -left-3 ring-8 ring-white">
                            <CheckCircle size={16} className="text-green-800" />
                          </span>
                          <h3 className="flex items-center text-lg font-semibold text-gray-900">Service Completed</h3>
                          <time className="block mb-2 text-sm font-normal leading-none text-gray-500">
                            {new Date(serviceRequest.estimatedCompletion).toLocaleString()}
                          </time>
                          <p className="text-sm font-normal text-gray-600">
                            Your device has been repaired and is ready for pickup.
                          </p>
                        </li>
                      )}
                    </ol>
                  </div>
                </div>
                
                {serviceRequest.status === 'Completed' && (
                  <div className="flex justify-center">
                    <button
                      type="button"
                      className="inline-flex items-center px-4 py-2 bg-blue-800 text-white rounded-lg font-semibold hover:bg-blue-700 transition duration-200"
                      onClick={() => alert('Invoice generation functionality would be implemented here')}
                    >
                      <FilePlus size={18} className="mr-2" />
                      Generate Invoice
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackingPage;