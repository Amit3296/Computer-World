import React from 'react';
import { Link } from 'react-router-dom';
import { Laptop, Printer, Monitor, PenTool as Tool, ArrowRight, CheckCircle } from 'lucide-react';

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-blue-700 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Expert Tech Repair Services You Can Trust
              </h1>
              <p className="text-xl text-blue-100">
                Professional repairs for desktops, laptops, and printers with guaranteed satisfaction.
              </p>
              <div className="pt-4">
                <Link 
                  to="/service-request" 
                  className="inline-flex items-center bg-white text-blue-900 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition duration-200"
                >
                  Request Service Now
                  <ArrowRight size={18} className="ml-2" />
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="relative">
                <div className="absolute -top-6 -left-6 w-48 h-48 bg-blue-400 rounded-full opacity-20"></div>
                <div className="absolute -bottom-8 -right-8 w-64 h-64 bg-blue-400 rounded-full opacity-20"></div>
                <div className="relative bg-blue-800 rounded-xl p-8 shadow-lg">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="bg-blue-700 p-4 rounded-lg flex flex-col items-center text-center">
                      <Monitor size={48} className="text-blue-300 mb-3" />
                      <span>Desktop Repair</span>
                    </div>
                    <div className="bg-blue-700 p-4 rounded-lg flex flex-col items-center text-center">
                      <Laptop size={48} className="text-blue-300 mb-3" />
                      <span>Laptop Repair</span>
                    </div>
                    <div className="bg-blue-700 p-4 rounded-lg flex flex-col items-center text-center">
                      <Printer size={48} className="text-blue-300 mb-3" />
                      <span>Printer Repair</span>
                    </div>
                    <div className="bg-blue-700 p-4 rounded-lg flex flex-col items-center text-center">
                      <Tool size={48} className="text-blue-300 mb-3" />
                      <span>Hardware Upgrades</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Our Services</h2>
            <p className="mt-4 text-xl text-gray-600">
              Professional repair services for all your tech needs
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-md overflow-hidden transition-transform duration-300 hover:transform hover:scale-105">
              <div className="p-6">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Monitor size={24} className="text-blue-800" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Desktop Repair</h3>
                <p className="text-gray-600 mb-4">
                  Expert desktop repair services for all makes and models. We fix hardware issues, upgrade components, and more.
                </p>
                <Link 
                  to="/service-request" 
                  className="inline-flex items-center text-blue-700 hover:text-blue-900"
                >
                  Request Service
                  <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-md overflow-hidden transition-transform duration-300 hover:transform hover:scale-105">
              <div className="p-6">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Laptop size={24} className="text-blue-800" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Laptop Repair</h3>
                <p className="text-gray-600 mb-4">
                  Comprehensive laptop repair services including screen replacement, keyboard repair, battery replacement, and more.
                </p>
                <Link 
                  to="/service-request" 
                  className="inline-flex items-center text-blue-700 hover:text-blue-900"
                >
                  Request Service
                  <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-md overflow-hidden transition-transform duration-300 hover:transform hover:scale-105">
              <div className="p-6">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Printer size={24} className="text-blue-800" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Printer Repair</h3>
                <p className="text-gray-600 mb-4">
                  Professional printer repair services for all major brands. We fix paper jams, connection issues, print quality problems, and more.
                </p>
                <Link 
                  to="/service-request" 
                  className="inline-flex items-center text-blue-700 hover:text-blue-900"
                >
                  Request Service
                  <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Us</h2>
            <p className="mt-4 text-xl text-gray-600">
              We provide fast, reliable, and affordable tech repair services
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <CheckCircle size={32} className="text-blue-800" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Expert Technicians</h3>
              <p className="text-gray-600">Certified professionals with years of experience</p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <CheckCircle size={32} className="text-blue-800" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Quick Turnaround</h3>
              <p className="text-gray-600">Fast repairs to get you back up and running</p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <CheckCircle size={32} className="text-blue-800" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Affordable Pricing</h3>
              <p className="text-gray-600">Competitive rates with no hidden fees</p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <CheckCircle size={32} className="text-blue-800" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Warranty</h3>
              <p className="text-gray-600">All repairs come with a service warranty</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to get your device fixed?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Our expert technicians are ready to help you with all your tech repair needs.
            Request a service today and get back to work in no time.
          </p>
          <Link 
            to="/service-request" 
            className="inline-flex items-center bg-white text-blue-900 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition duration-200"
          >
            Request Service Now
            <ArrowRight size={18} className="ml-2" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;