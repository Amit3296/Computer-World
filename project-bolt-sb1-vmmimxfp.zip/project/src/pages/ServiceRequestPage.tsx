import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useServiceRequest } from '../context/ServiceRequestContext';
import { Check, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

// Hardware makes for dropdowns
const makes = {
  Desktop: ['Dell', 'HP', 'Lenovo', 'Apple', 'Asus', 'Acer', 'Custom Built', 'Other'],
  Laptop: ['Dell', 'HP', 'Lenovo', 'Apple', 'Asus', 'Acer', 'Microsoft', 'MSI', 'Other'],
  Printer: ['HP', 'Epson', 'Canon', 'Brother', 'Xerox', 'Samsung', 'Lexmark', 'Other']
};

// Issues for each device type
const issues = {
  Desktop: ['Power on no display', 'No Power', 'Slow Performance', 'Overheating', 'Blue Screen', 'Hardware Upgrade', 'Other'],
  Laptop: ['Power on no display', 'No Power', 'Battery Issues', 'Screen Damage', 'Keyboard Issues', 'Overheating', 'Other'],
  Printer: ['Paper Jam issue', 'Print Quality Problems', 'Connection Issues', 'Ink/Toner Problems', 'Error Messages', 'Other']
};

// Service charges
const serviceCharges = {
  Desktop: {
    'Power on no display': '₹500',
    'No Power': '₹600',
    'Slow Performance': '₹400',
    'Overheating': '₹700',
    'Blue Screen': '₹500',
    'Hardware Upgrade': '₹800',
    'Other': '₹500'
  },
  Laptop: {
    'Power on no display': '₹600',
    'No Power': '₹700',
    'Battery Issues': '₹800',
    'Screen Damage': '₹1500',
    'Keyboard Issues': '₹900',
    'Overheating': '₹800',
    'Other': '₹600'
  },
  Printer: {
    'Paper Jam issue': '₹500',
    'Print Quality Problems': '₹600',
    'Connection Issues': '₹400',
    'Ink/Toner Problems': '₹500',
    'Error Messages': '₹400',
    'Other': '₹500'
  }
};

const ServiceRequestPage = () => {
  const navigate = useNavigate();
  const { addServiceRequest } = useServiceRequest();
  
  const [formData, setFormData] = useState({
    customerName: '',
    contactNumber: '',
    deviceType: 'Desktop',
    make: '',
    model: '',
    serialNumber: '',
    issue: '',
  });
  
  const [availableMakes, setAvailableMakes] = useState(makes.Desktop);
  const [availableIssues, setAvailableIssues] = useState(issues.Desktop);
  const [serviceCharge, setServiceCharge] = useState('₹500');
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Update available makes when device type changes
  useEffect(() => {
    setAvailableMakes(makes[formData.deviceType] || []);
    setAvailableIssues(issues[formData.deviceType] || []);
    setFormData(prev => ({
      ...prev,
      make: '',
      issue: ''
    }));
    setServiceCharge('₹500');
  }, [formData.deviceType]);
  
  // Update service charge when issue changes
  useEffect(() => {
    if (formData.deviceType && formData.issue) {
      setServiceCharge(serviceCharges[formData.deviceType][formData.issue] || '₹500');
    }
  }, [formData.deviceType, formData.issue]);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when field is edited
    if (formErrors[name]) {
      setFormErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };
  
  const validateForm = () => {
    const errors = {};
    if (!formData.customerName.trim()) errors.customerName = 'Customer name is required';
    if (!formData.contactNumber.trim()) {
      errors.contactNumber = 'Contact number is required';
    } else if (!/^\d{10}$/.test(formData.contactNumber)) {
      errors.contactNumber = 'Contact number must be 10 digits';
    }
    if (!formData.make) errors.make = 'Make is required';
    if (!formData.model.trim()) errors.model = 'Model is required';
    if (!formData.issue) errors.issue = 'Issue is required';
    
    return errors;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    
    setIsSubmitting(true);
    
    // Generate random service ID
    const serviceId = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Create service request object
    const serviceRequest = {
      id: serviceId,
      ...formData,
      serviceCharge,
      status: 'Pending',
      createdAt: new Date().toISOString(),
      estimatedCompletion: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString() // 3 days from now
    };
    
    // Add to context
    addServiceRequest(serviceRequest);
    
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success('Service request submitted successfully!');
      navigate(`/track?id=${serviceId}`);
    }, 1500);
  };
  
  return (
    <div className="py-10 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-blue-800 px-6 py-4">
            <h1 className="text-2xl font-bold text-white">Service Request Form</h1>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6">
            <div className="space-y-6">
              {/* Customer Information */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Customer Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="customerName" className="block text-sm font-medium text-gray-700 mb-1">
                      Customer Name*
                    </label>
                    <input
                      type="text"
                      id="customerName"
                      name="customerName"
                      value={formData.customerName}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        formErrors.customerName ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {formErrors.customerName && (
                      <p className="mt-1 text-sm text-red-600 flex items-center">
                        <AlertCircle size={14} className="mr-1" />
                        {formErrors.customerName}
                      </p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-1">
                      Contact Number*
                    </label>
                    <input
                      type="text"
                      id="contactNumber"
                      name="contactNumber"
                      value={formData.contactNumber}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        formErrors.contactNumber ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {formErrors.contactNumber && (
                      <p className="mt-1 text-sm text-red-600 flex items-center">
                        <AlertCircle size={14} className="mr-1" />
                        {formErrors.contactNumber}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Hardware Details */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Hardware Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="deviceType" className="block text-sm font-medium text-gray-700 mb-1">
                      Device Type*
                    </label>
                    <select
                      id="deviceType"
                      name="deviceType"
                      value={formData.deviceType}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="Desktop">Desktop</option>
                      <option value="Laptop">Laptop</option>
                      <option value="Printer">Printer</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="make" className="block text-sm font-medium text-gray-700 mb-1">
                      Make*
                    </label>
                    <select
                      id="make"
                      name="make"
                      value={formData.make}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        formErrors.make ? 'border-red-500' : 'border-gray-300'
                      }`}
                    >
                      <option value="">Select Make</option>
                      {availableMakes.map((make) => (
                        <option key={make} value={make}>
                          {make}
                        </option>
                      ))}
                    </select>
                    {formErrors.make && (
                      <p className="mt-1 text-sm text-red-600 flex items-center">
                        <AlertCircle size={14} className="mr-1" />
                        {formErrors.make}
                      </p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="model" className="block text-sm font-medium text-gray-700 mb-1">
                      Model*
                    </label>
                    <input
                      type="text"
                      id="model"
                      name="model"
                      value={formData.model}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        formErrors.model ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {formErrors.model && (
                      <p className="mt-1 text-sm text-red-600 flex items-center">
                        <AlertCircle size={14} className="mr-1" />
                        {formErrors.model}
                      </p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="serialNumber" className="block text-sm font-medium text-gray-700 mb-1">
                      Serial Number (optional)
                    </label>
                    <input
                      type="text"
                      id="serialNumber"
                      name="serialNumber"
                      value={formData.serialNumber}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
              
              {/* Problem Description */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Problem Description</h2>
                <div>
                  <label htmlFor="issue" className="block text-sm font-medium text-gray-700 mb-1">
                    Issue*
                  </label>
                  <select
                    id="issue"
                    name="issue"
                    value={formData.issue}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                      formErrors.issue ? 'border-red-500' : 'border-gray-300'
                    }`}
                  >
                    <option value="">Select Issue</option>
                    {availableIssues.map((issue) => (
                      <option key={issue} value={issue}>
                        {issue}
                      </option>
                    ))}
                  </select>
                  {formErrors.issue && (
                    <p className="mt-1 text-sm text-red-600 flex items-center">
                      <AlertCircle size={14} className="mr-1" />
                      {formErrors.issue}
                    </p>
                  )}
                </div>
              </div>
              
              {/* Service Charges */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Service Charges</h2>
                <p className="text-gray-700">
                  Estimated charges: <span className="font-semibold text-blue-800">{serviceCharge}</span>
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  Final charges may vary based on the actual diagnosis.
                </p>
              </div>
              
              {/* Payment Information */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Payment Information</h2>
                <p className="text-gray-700">
                  Payment methods accepted:
                </p>
                <ul className="list-disc list-inside text-gray-700 mt-2">
                  <li>PhonePe/Google Pay: 8926179060</li>
                  <li>Cash on service completion</li>
                </ul>
                <p className="text-sm text-gray-500 mt-2">
                  An invoice will be generated upon service completion.
                </p>
              </div>
              
              {/* Submit Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full bg-blue-800 text-white py-3 rounded-lg font-semibold ${
                    isSubmitting ? 'opacity-70 cursor-not-allowed' : 'hover:bg-blue-700'
                  } transition duration-200`}
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                        <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </span>
                  ) : (
                    'Submit Service Request'
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ServiceRequestPage;