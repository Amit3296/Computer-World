import React, { useState } from 'react';
import { useServiceRequest } from '../context/ServiceRequestContext';
import { Search, Monitor, Laptop, Printer, Sliders, Edit2, Check, X, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

const AdminDashboard = () => {
  const { serviceRequests, updateServiceRequest, removeServiceRequest } = useServiceRequest();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [deviceFilter, setDeviceFilter] = useState('All');
  const [editingId, setEditingId] = useState(null);
  const [editedStatus, setEditedStatus] = useState('');
  
  // Filter service requests
  const filteredRequests = serviceRequests.filter(request => {
    const matchesSearch = 
      request.id.includes(searchTerm) || 
      request.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.contactNumber.includes(searchTerm);
    
    const matchesStatus = statusFilter === 'All' || request.status === statusFilter;
    const matchesDevice = deviceFilter === 'All' || request.deviceType === deviceFilter;
    
    return matchesSearch && matchesStatus && matchesDevice;
  });
  
  const handleUpdateStatus = (id) => {
    updateServiceRequest(id, { status: editedStatus });
    setEditingId(null);
    toast.success('Service request status updated successfully!');
  };
  
  const handleRemoveRequest = (id) => {
    if (window.confirm('Are you sure you want to delete this service request?')) {
      removeServiceRequest(id);
      toast.success('Service request deleted successfully!');
    }
  };
  
  const getDeviceIcon = (type) => {
    switch (type) {
      case 'Desktop':
        return <Monitor size={20} />;
      case 'Laptop':
        return <Laptop size={20} />;
      case 'Printer':
        return <Printer size={20} />;
      default:
        return <Monitor size={20} />;
    }
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800';
      case 'Completed':
        return 'bg-green-100 text-green-800';
      case 'Cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="py-10 bg-gray-50 min-h-[calc(100vh-64px-275px)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-blue-800 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between">
            <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
            <p className="text-blue-200 mt-1 md:mt-0">Manage service requests</p>
          </div>
          
          <div className="p-6">
            {/* Filters */}
            <div className="mb-6 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center md:space-x-4 space-y-4 md:space-y-0">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by ID, customer name or phone"
                    className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div className="flex items-center space-x-4">
                  <div>
                    <label htmlFor="statusFilter" className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <select
                      id="statusFilter"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="All">All Statuses</option>
                      <option value="Pending">Pending</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="deviceFilter" className="block text-sm font-medium text-gray-700 mb-1">
                      Device Type
                    </label>
                    <select
                      id="deviceFilter"
                      value={deviceFilter}
                      onChange={(e) => setDeviceFilter(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="All">All Devices</option>
                      <option value="Desktop">Desktop</option>
                      <option value="Laptop">Laptop</option>
                      <option value="Printer">Printer</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Service Requests List */}
            {filteredRequests.length === 0 ? (
              <div className="bg-gray-50 rounded-lg p-8 text-center">
                <Sliders size={48} className="mx-auto text-gray-400 mb-3" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No service requests found</h3>
                <p className="text-gray-600">Try adjusting your search or filter criteria</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ID
                      </th>
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Customer
                      </th>
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Device
                      </th>
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Issue
                      </th>
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created
                      </th>
                      <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredRequests.map((request) => (
                      <tr key={request.id} className="hover:bg-gray-50">
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {request.id}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{request.customerName}</div>
                          <div className="text-sm text-gray-500">{request.contactNumber}</div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            {getDeviceIcon(request.deviceType)}
                            <span className="ml-2 text-sm text-gray-900">
                              {request.make} {request.model}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {request.issue}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {editingId === request.id ? (
                            <select
                              value={editedStatus}
                              onChange={(e) => setEditedStatus(e.target.value)}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            >
                              <option value="Pending">Pending</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          ) : (
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(request.status)}`}>
                              {request.status}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(request.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                          {editingId === request.id ? (
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={() => handleUpdateStatus(request.id)}
                                className="text-green-600 hover:text-green-800"
                              >
                                <Check size={18} />
                              </button>
                              <button
                                onClick={() => setEditingId(null)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <X size={18} />
                              </button>
                            </div>
                          ) : (
                            <div className="flex justify-end space-x-3">
                              <button
                                onClick={() => {
                                  setEditingId(request.id);
                                  setEditedStatus(request.status);
                                }}
                                className="text-blue-600 hover:text-blue-800"
                                title="Edit status"
                              >
                                <Edit2 size={18} />
                              </button>
                              <button
                                onClick={() => handleRemoveRequest(request.id)}
                                className="text-red-600 hover:text-red-800"
                                title="Delete request"
                              >
                                <X size={18} />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            
            {/* Stats Summary */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-800">Total Requests</p>
                    <p className="text-2xl font-semibold text-blue-900">{serviceRequests.length}</p>
                  </div>
                  <RefreshCw size={24} className="text-blue-500" />
                </div>
              </div>
              
              <div className="bg-yellow-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-yellow-800">Pending</p>
                    <p className="text-2xl font-semibold text-yellow-900">
                      {serviceRequests.filter(r => r.status === 'Pending').length}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                    <span className="text-yellow-600 font-medium">
                      {Math.round((serviceRequests.filter(r => r.status === 'Pending').length / serviceRequests.length) * 100 || 0)}%
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-800">In Progress</p>
                    <p className="text-2xl font-semibold text-blue-900">
                      {serviceRequests.filter(r => r.status === 'In Progress').length}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-blue-600 font-medium">
                      {Math.round((serviceRequests.filter(r => r.status === 'In Progress').length / serviceRequests.length) * 100 || 0)}%
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="bg-green-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-800">Completed</p>
                    <p className="text-2xl font-semibold text-green-900">
                      {serviceRequests.filter(r => r.status === 'Completed').length}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <span className="text-green-600 font-medium">
                      {Math.round((serviceRequests.filter(r => r.status === 'Completed').length / serviceRequests.length) * 100 || 0)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;