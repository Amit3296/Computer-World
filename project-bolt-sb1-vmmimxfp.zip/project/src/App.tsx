import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ServiceRequestPage from './pages/ServiceRequestPage';
import TrackingPage from './pages/TrackingPage';
import AdminDashboard from './pages/AdminDashboard';
import { ServiceRequestProvider } from './context/ServiceRequestContext';
import { Toaster } from 'react-hot-toast';

function App() {
  return (
    <ServiceRequestProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/service-request" element={<ServiceRequestPage />} />
              <Route path="/track" element={<TrackingPage />} />
              <Route path="/admin" element={<AdminDashboard />} />
            </Routes>
          </main>
          <Footer />
        </div>
        <Toaster position="top-center" />
      </Router>
    </ServiceRequestProvider>
  );
}

export default App;